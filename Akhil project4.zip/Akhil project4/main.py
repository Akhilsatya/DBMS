
from flask import *
import sqlite3
import random
import mail

app = Flask(__name__)

@app.route('/',methods = ["POST","GET"])
def login():
    with sqlite3.connect("course.db") as con:  
        con.execute('''CREATE TABLE IF NOT EXISTS student (
            name varchar(20) not null,
            email varchar(20) not null,
            regno varchar(20) not null,
            password varchar(20) not null)''')
        con.commit()
    with sqlite3.connect("course.db") as con:  
        con.execute('''CREATE TABLE IF NOT EXISTS student (
            name varchar(20) not null,
            email varchar(20) not null,
            regno varchar(20) not null,
            password varchar(20) not null)''')
        con.commit()
    if request.method == "GET":
        return render_template("index.html")
    else:
        otp = request.form['otp']
        if str(otpdigit) == otp:
            with sqlite3.connect("course.db") as con:
                con.execute(
                    "INSERT into student (email, password, name, regno) values (?,?,?,?)",(email, password, name, regno))
            return render_template("index.html")
        else:
            return "Invalid Credentials"
@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/register/otp',methods = ['POST',"GET"])
def otp():
    global otpdigit,name,email,password,regno
    otpdigit = random.randint(1000,9999)
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    regno = request.form['regno']
    mail.email(email,otpdigit)
    return render_template("otp.html")

@app.route('/home/', methods=['POST'])
def home():
    global regno
    if request.method == "POST":
        regno = request.form['regno']
        password = request.form['password']
        con = sqlite3.connect("course.db")
        #con.execute("SELECT email,password FROM tourist")
        cursor_obj = con.cursor()
        cursor_obj.execute("SELECT regno,password FROM student")
        data = cursor_obj.fetchall()
        list_data = []
        data_dict = dict()
        for i in data:
            list_data.append(list(i))
        for i in list_data:
            data_dict[i[0]] = i[1]
        for i in list_data:
            if data_dict[regno] != password:
                return  "Wrong password or invalid Registration id"
            else:
                cursor_obj.execute("SELECT regno FROM courseregister")
                list_regno = []
                data = cursor_obj.fetchall()
                for i in data:
                    for j in i:
                        list_regno.append(j)
                if regno not in list_regno:
                    cursor_obj.execute("SELECT course_name FROM courses")
                    data = cursor_obj.fetchall()
                    list_courses = []
                    for i in data:
                        for j in i:
                            list_courses.append(j)
                    cursor_obj.execute("SELECT faculty_name FROM faculty")
                    data = cursor_obj.fetchall()
                    list_faculty = []
                    for i in data:
                        for j in i:
                            list_faculty.append(j)
                    return render_template("course.html",list_courses = list_courses,list_faculty = list_faculty)
                else:
                    cursor_obj.execute("SELECT * FROM courseregister WHERE regno = "+regno+"")
                    data = cursor_obj.fetchall()
                    list_course = []
                    for i in data:
                        for j in i:
                            list_course.append(j)
                    print(list_course)
                    cursor_obj.execute('''
                            SELECT course_id,credits,course_type,course_category FROM courses WHERE 
                            course_name = '''+"'"+list_course[1]+"'"+'''OR
                            course_name = '''+"'"+list_course[2]+"'"+'''OR
                            course_name = '''+"'"+list_course[3]+"'"+'''OR
                            course_name = '''+"'"+list_course[4]+"'"+'''OR
                            course_name = '''+"'"+list_course[5]+"'"+'''OR
                            course_name = '''+"'"+list_course[6]+"'"+'''OR
                            course_name = '''+"'"+list_course[7]+"'"+'''OR
                            course_name = '''+"'"+list_course[8]+"'"+'''OR
                            course_name = '''+"'"+list_course[9]+"'"+'''OR
                            course_name = '''+"'"+list_course[10]+"'"+'''OR
                            course_name = '''+"'"+list_course[11]+"'"+''';''')
                    data = cursor_obj.fetchall()
                    list_course_name = []
                    list_faculty = []
                    for i in data:
                        list_course_name.append(i)
                    print(list_course_name)
                    cursor_obj.execute("SELECT * FROM facultyregister")
                    data = cursor_obj.fetchall()
                    for i in data:
                        for j in i:
                            list_faculty.append(j)
                    cursor_obj.execute("SELECT * FROM student WHERE regno = "+regno+"")
                    data = cursor_obj.fetchall()
                    list_details = []
                    for i in data:
                        list_details.append(i)
                    list_course = [list_course]
                    print(list_faculty)
                    cursor_obj.execute('''
                            SELECT faculty_id,building_name,room_no FROM faculty WHERE 
                            faculty_name = '''+"'"+list_faculty[1]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[2]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[3]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[4]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[5]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[6]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[7]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[8]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[9]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[10]+"'"+'''OR
                            faculty_name = '''+"'"+list_faculty[11]+"'"+''';''')
                    
                    data = cursor_obj.fetchall()
                    list_faculty_name = []
                    for i in data:
                        list_faculty_name.append(i)
                    print("lisus", list_faculty_name)
                    print(list_faculty)
                    return render_template("home.html",list_course = list_course,list_faculty = list_faculty,list_details = list_details,list_course_name = list_course_name,list_faculty_name = list_faculty_name)
    
@app.route("/timetable", methods=["POST"])
def timetable():
    if request.method == "POST":
        course1 = request.form['course1']
        course2 = request.form['course2']
        course3 = request.form['course3']
        course4 = request.form['course4']
        course5 = request.form['course5']
        course6 = request.form['course6']
        course7 = request.form['course7']
        course8 = request.form['course8']
        course9 = request.form['course9']
        course10 = request.form['course10']
        course11 = request.form['course11']
        faculty1 = request.form['faculty1']
        faculty2 = request.form['faculty2']
        faculty3 = request.form['faculty3']
        faculty4 = request.form['faculty4']
        faculty5 = request.form['faculty5']
        faculty6 = request.form['faculty6']
        faculty7 = request.form['faculty7']
        faculty8 = request.form['faculty8']
        faculty9 = request.form['faculty9']
        faculty10 = request.form['faculty10']
        faculty11 = request.form['faculty11']
        with sqlite3.connect("course.db") as con:
                con.execute(
                    '''INSERT into facultyregister (regno, 
                    faculty1, 
                    faculty2, 
                    faculty3, 
                    faculty4, 
                    faculty5, 
                    faculty6, 
                    faculty7, 
                    faculty8, 
                    faculty9, 
                    faculty10,
                    faculty11 ) values (?,?,?,?,?,?,?,?,?,?,?,?)''',(regno.replace("_"," "),
                                                                    faculty1.replace("_"," "), 
                                                                    faculty2.replace("_"," "), 
                                                                    faculty3.replace("_"," "), 
                                                                    faculty4.replace("_"," "), 
                                                                    faculty5.replace("_"," "), 
                                                                    faculty6.replace("_"," "), 
                                                                    faculty7.replace("_"," "), 
                                                                    faculty8.replace("_"," "), 
                                                                    faculty9.replace("_"," "), 
                                                                    faculty10.replace("_"," "),
                                                                    faculty11.replace("_"," ")))
        
        with sqlite3.connect("course.db") as con:
                con.execute(
                    '''INSERT into courseregister (regno, 
                    course1, 
                    course2, 
                    course3, 
                    course4, 
                    course5, 
                    course6, 
                    course7, 
                    course8, 
                    course9, 
                    course10,
                    course11 ) values (?,?,?,?,?,?,?,?,?,?,?,?)''',(regno,
                                                                    course1.replace("_"," "), 
                                                                    course2.replace("_"," "), 
                                                                    course3.replace("_"," "), 
                                                                    course4.replace("_"," "), 
                                                                    course5.replace("_"," "), 
                                                                    course6.replace("_"," "), 
                                                                    course7.replace("_"," "), 
                                                                    course8.replace("_"," "), 
                                                                    course9.replace("_"," "), 
                                                                    course10.replace("_"," "),
                                                                    course11.replace("_"," ")))
        
        con = sqlite3.connect("course.db")
        cursor_obj = con.cursor()
        cursor_obj.execute("SELECT * FROM courseregister WHERE regno = "+regno+"")
        data = cursor_obj.fetchall()
        list_course = []
        list_faculty = []
        for i in data:
            list_course.append(list(i))
        cursor_obj.execute("SELECT * FROM facultyregister")
        data = cursor_obj.fetchall()
        for i in data:
            list_faculty.append(list(i))
        cursor_obj.execute("SELECT * FROM student WHERE regno = "+regno+"")
        data = cursor_obj.fetchall()
        list_details = []
        for i in data:
            list_details.append(i)
        print(course3)
        cursor_obj.execute('''
                            SELECT course_id,credits,course_type,course_category FROM courses WHERE 
                            course_name = '''+"'"+course1.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course2.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course3.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course4.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course5.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course6.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course7.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course8.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course9.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course10.replace("_"," ")+"'"+'''OR
                            course_name = '''+"'"+course11.replace("_"," ")+"'"+''';''')
        data = cursor_obj.fetchall()
        list_course_name = []
        for i in data:
            list_course_name.append(i)
        print(list_course_name)
        cursor_obj.execute('''
                            SELECT faculty_id,building_name,room_no FROM faculty WHERE 
                            faculty_name = '''+"'"+faculty1.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty2.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty3.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty4.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty5.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty6.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty7.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty8.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty9.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty10.replace("_"," ")+"'"+'''OR
                            faculty_name = '''+"'"+faculty11.replace("_"," ")+"'"+''';''')
        data = cursor_obj.fetchall()
        list_faculty_name = []
        for i in data:
            list_faculty_name.append(i)
        print(list_faculty_name)
        print(list_course_name)
        return render_template("home.html",list_course = list_course,list_faculty = list_faculty,list_details = list_details,list_course_name = list_course_name,list_faculty_name = list_faculty_name)

        

        



if __name__ == "__main__":
    app.run(debug = True)


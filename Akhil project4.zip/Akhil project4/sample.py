import sqlite3
con = sqlite3.connect("course.db")
cursor_obj = con.cursor()
course1 = "Design_and_Analysis_of_Algorithms_Lab"
c = course1.replace("_"," ")
print(c)
course2 = "Artificial_Neural_Networks_Lab"
cursor_obj.execute('''SELECT course_id FROM courses where
                    course_name = '''+"'"+course1.replace("_"," ")+"'"+''';''')
data = cursor_obj.fetchall()
list_course_name = []
for i in data:
    list_course_name.append(i)

print(list_course_name)